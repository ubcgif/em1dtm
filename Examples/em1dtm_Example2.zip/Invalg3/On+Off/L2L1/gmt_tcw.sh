#!/bin/csh
#
# For plotting em1dtm predicted data.
#

gmtset PAPER_MEDIA letter+
gmtset PAGE_ORIENTATION portrait
gmtset ANOT_FONT_SIZE 12
gmtset LABEL_FONT_SIZE 16
gmtset TICK_LENGTH 0.20

set PSFILE = 'tcw.eps'
set PDFFILE = 'tcw.pdf'

set AXES  = '-JX12.0/8.0'
set REGION  = '-R-0.1E-02/16.E-00/-2.0E+01/4.0E+02'
set XY0 = '-X0. -Y0.'
set XY1 = '-X5.0 -Y3.0'

set DATA = 'tcw_Geo_trunc'
awk 'NF > 1 {print $1,$2}' ${DATA} >! temp
psxy  temp  ${AXES}  ${REGION}  -Bf5.a5.:"Time  (ms)":/f100.a100.:"Current  (A)":WSne  \
          -W4/0/0/0  ${XY1}  -K   >!  ${PSFILE}
psxy  temp  -JX  -R  -Sc0.1c ${XY0}  -O  >>  ${PSFILE}


ps2pdf ${PSFILE} ${PDFFILE}
echo ${PDFFILE} ' done'

\rm temp

exit

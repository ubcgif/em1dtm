#!/bin/csh
#
# For plotting em1dtm predicted data.
#

gmtset PAPER_MEDIA letter+
gmtset PAGE_ORIENTATION portrait
gmtset ANOT_FONT_SIZE 12
gmtset LABEL_FONT_SIZE 16
gmtset TICK_LENGTH 0.20

head  -36  ../on+off_out.obs |  tail -30  |  awk '{print $1,$3,$5}' -    >! tV_noisy
tail  -30  test.prd          |               awk '{print $1,$3}' -       >! tV

../../../../Test03/thtodpth << EOI
test.con
model
EOI

cat >! truemodel << EOI
  0.  0.03
 40.  0.03
 40.  0.4
 70.  0.4
 70.  0.005
220.  0.005
220.  0.2
300.  0.2
500.  0.2
600.  0.2
700.  0.2
EOI

awk 'NR > 9 && NF > 7 && NF < 11  {print $1,$3}'  test_001.dgns  >!  iterphid
awk 'NR > 9 && NF > 7 && NF < 11  {print $1,$4}'  test_001.dgns  >!  iterbeta
awk 'NR > 9 && NF > 7 && NF < 11  {print $1,$5}'  test_001.dgns  >!  iterphim
awk 'NR > 10 && NF > 7 && NF < 11  {print $1,$6}'  test_001.dgns  >!  iterPhi
awk 'NR > 10 && NF > 7 && NF < 11  {print $1,$8}'  test_001.dgns  >!  iterlam

set PSFILED = 'd.eps'
set PDFFILED = 'd.pdf'
set PSFILEM = 'm.eps'
set PDFFILEM = 'm.pdf'
set PSFILEI = 'ip.eps'
set PDFFILEI = 'ip.pdf'

set AXES  = '-JX12.0/10.0'
set AXES2  = '-JX12.0/10.0l'
set REGION  = '-R-0.1E-02/16.E-00/-1.2E+01/1.2E+01'
set REGION2  = '-R-0.1E-02/16.E-00/0.1E-03/2.0E+01'
set AXEST  = '-JX12.0/10.0 -R0./12.0/0./10.0'
set AXESM  = '-JX12.0/8.0l'
set REGIONM  = '-R0.0/4.1E+02/0.1E-02/1.0E-00'
set AXES1  = '-JX14.0/14.0l'
set REGION1  = '-R-1.0/30.0/0.1E-01/1.0E+05'
set XY0 = '-X0. -Y0.'
set XY1 = '-X5.0 -Y3.0'
set XY2 = '-X0. -Y12.0'

set TITLESTUFF = '6. 10.5 14 0. 0 BC '
set TITLE = 'EM1DTM'

set DATA = 'tV'
psxy  ${DATA}  ${AXES}  ${REGION}  -Bf5.a5.:"Time  (ms)":/f2.a2.:"Voltage  (@~m@~V)":WSne  \
          -W4/0/0/0  ${XY1}  -K   >!  ${PSFILED}
set DATA = 'tV_noisy'
psxy  ${DATA}  -JX  -R  -Sc0.1c -Ey0.2/3/0/0/0 ${XY0}  -O -K  >>  ${PSFILED}

# echo ${TITLESTUFF} ${TITLE} | pstext  ${AXEST}  -N ${XY0} -O -K  >>  ${PSFILED}
pstext  ${AXEST}  -N ${XY0} -O -K  << EOI  >>  ${PSFILED}
11.5 9.5 16 0. 4 TR  (b)
EOI


set DATA = 'tV'
awk '{print $1,sqrt($2*$2)}' ${DATA}  >! temp.xy
psxy  temp.xy  ${AXES2}  ${REGION2}  -Bf5.a5./f3a1:"Voltage  (@~m@~V)":WSne  \
          -W4/0/0/0  ${XY2}  -O -K   >>  ${PSFILED}
set DATA = 'tV_noisy'
awk '{print $1,sqrt($2*$2),$3}' ${DATA}  >! temp.xy
psxy  temp.xy  -JX  -R  -Sc0.1c -Ey0.2/3/0/0/0  ${XY0}  -O -K  >>  ${PSFILED}

# echo ${TITLESTUFF} ${TITLE} | pstext  ${AXEST}  -N ${XY0} -O   >>  ${PSFILED}
pstext  ${AXEST}  -N ${XY0} -O  << EOI  >>  ${PSFILED}
11.5 9.5 16 0. 4 TR  (a)
EOI


ps2pdf ${PSFILED} ${PDFFILED}
echo ${PDFFILED} ' done'


psxy  model  ${AXESM}  ${REGIONM}  -Bf50a100:"Depth  (m)":/f3a1:"Conductivity  (S/m)":WSne  \
          -W4/0/0/0  ${XY1}  -K   >!  ${PSFILEM}

psxy  truemodel  -JX  -R  -W2  ${XY0}  -O  >>  ${PSFILEM}


ps2pdf ${PSFILEM} ${PDFFILEM}
echo ${PDFFILEM} ' done'


psxy  iterphid  ${AXES1}  ${REGION1}  -Bf1a5:"Iteration":/f3a1:"Phis":WSne  \
          -Sc0.3c -W3  ${XY1}  -K   >!  ${PSFILEI}
psxy  iterphid  -JX  -R  -W2/0/0/0  ${XY0}  -O -K  >>  ${PSFILEI}
psxy  iterbeta  -JX  -R  -Sx0.3c -W3  ${XY0}  -O -K  >>  ${PSFILEI}
psxy  iterbeta  -JX  -R  -W2/0/0/0  ${XY0}  -O -K  >>  ${PSFILEI}
psxy  iterphim  -JX  -R  -Sd0.3c -W3  ${XY0}  -O -K  >>  ${PSFILEI}
psxy  iterphim  -JX  -R  -W2/0/0/0  ${XY0}  -O -K  >>  ${PSFILEI}
psxy  iterPhi   -JX  -R  -Sc0.2c -W3 -G0  ${XY0}  -O -K  >>  ${PSFILEI}
psxy  iterPhi   -JX  -R  -W2/0/0/0  ${XY0}  -O -K  >>  ${PSFILEI}
psxy  iterlam   -JX  -R  -Ss0.2c -W3  ${XY0}  -O   >>  ${PSFILEI}


ps2pdf ${PSFILEI} ${PDFFILEI}
echo ${PDFFILEI} ' done'

\rm truemodel temp.xy model iterphid iterbeta iterphim iterPhi iterlam

exit

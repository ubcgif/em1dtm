#!/bin/csh
#
# For plotting em1dtm predicted data.
#

gmtset PAPER_MEDIA letter+
gmtset PAGE_ORIENTATION portrait
gmtset ANOT_FONT_SIZE 12
gmtset LABEL_FONT_SIZE 16
gmtset TICK_LENGTH 0.20

head  -34  em1dtmfwd.out  |  tail -30  |  awk '{print $1,$3,$5}' -    >! tV_noisy
tail  -30  em1dtmfwd.out  |               awk '{print $1,$3}' -       >! tV

set PSFILE = 'tV.eps'
set PDFFILE = 'tV.pdf'

set AXES  = '-JX12.0/10.0'
set AXES2  = '-JX12.0/10.0l'
set REGION  = '-R-0.1E-02/16.E-00/-1.2E+01/1.2E+01'
set REGION2  = '-R-0.1E-02/16.E-00/0.1E-03/2.0E+01'
set AXEST  = '-JX12.0/10.0 -R0./12.0/0./10.0'
set XY0 = '-X0. -Y0.'
set XY1 = '-X5.0 -Y3.0'
set XY2 = '-X0. -Y13.5'

set TITLESTUFF = '6. 10.5 14 0. 0 BC '
set TITLE = 'EM1DTMFWD'

set DATA = 'tV'
psxy  ${DATA}  ${AXES}  ${REGION}  -Bf5.a5.:"Time  (ms)":/f2.a2.:"Voltage  (@~m@~V)":WSne  \
          -W4/0/0/0  ${XY1}  -K   >!  ${PSFILE}
set DATA = 'tV_noisy'
psxy  ${DATA}  -JX  -R  -Sc0.1c -Ey0.2/3/0/0/0 ${XY0}  -O -K  >>  ${PSFILE}

echo ${TITLESTUFF} ${TITLE} | pstext  ${AXEST}  -N ${XY0} -O -K  >>  ${PSFILE}


set DATA = 'tV'
awk '{print $1,sqrt($2*$2)}' ${DATA}  >! temp.xy
psxy  temp.xy  ${AXES2}  ${REGION2}  -Bf5.a5.:"Time  (s)":/f3a1:"Voltage  (@~m@~V)":WSne  \
          -W4/0/0/0  ${XY2}  -O -K   >>  ${PSFILE}
set DATA = 'tV_noisy'
awk '{print $1,sqrt($2*$2),$3}' ${DATA}  >! temp.xy
psxy  temp.xy  -JX  -R  -Sc0.1c -Ey0.2/3/0/0/0  ${XY0}  -O -K  >>  ${PSFILE}

echo ${TITLESTUFF} ${TITLE} | pstext  ${AXEST}  -N ${XY0} -O   >>  ${PSFILE}


ps2pdf ${PSFILE} ${PDFFILE}
echo ${PDFFILE} ' done'


exit

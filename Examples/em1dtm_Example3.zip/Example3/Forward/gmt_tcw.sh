#!/bin/csh #
# For plotting em1dtm predicted data.
#

gmtset PAPER_MEDIA letter+
gmtset PAGE_ORIENTATION portrait
gmtset ANOT_FONT_SIZE 12
gmtset LABEL_FONT_SIZE 16
gmtset TICK_LENGTH 0.20

set PSFILE = 'tcw_VTEM.eps'
set PDFFILE = 'tcw_VTEM.pdf'

set AXES  = '-JX12.0/10.0'
set REGION  = '-R-0.2E-00/7.5E-00/0.0E-00/1.1E-00'
set AXEST  = '-JX12.0/10.0 -R0./12.0/0./10.0'
set XY0 = '-X0. -Y0.'
set XY1 = '-X5.0 -Y3.0'

set TITLESTUFF = '6. 10.5 14 0. 0 BC '
set TITLE = 'VTEM waveform'

set DATA = 'tcw_VTEM'
awk 'NF > 1 {print $1,$2}'  ${DATA}  >! temp.xy
psxy  temp.xy  ${AXES}  ${REGION}  -Bf1.a2.:"Time  (ms)":/f0.2a1.:"Current  (A)":WSne  \
          -Sc0.05  ${XY1}  -K   >!  ${PSFILE}

set DATA = 'tcw_VTEM_dec'
awk 'NF > 1 {print $1,$2}'  ${DATA}  >! temp.xy
psxy  temp.xy  ${AXES}  ${REGION}  -Sc0.1 -G0  ${XY0}  -O -K   >>  ${PSFILE}

set DATA = 'tcw_VTEM_dec2'
awk 'NF > 1 {print $1,$2}'  ${DATA}  >! temp.xy
psxy  temp.xy  ${AXES}  ${REGION}  -Sx0.3 -W3  ${XY0}  -O -K   >>  ${PSFILE}
psxy  temp.xy  ${AXES}  ${REGION}  -W3  ${XY0}  -O -K   >>  ${PSFILE}

echo ${TITLESTUFF} ${TITLE} | pstext  ${AXEST}  -N ${XY0} -O  >>  ${PSFILE}


ps2pdf ${PSFILE} ${PDFFILE}
echo ${PDFFILE} ' done'


set PSFILE = 'tcw_VTEM_good.eps'
set PDFFILE = 'tcw_VTEM_good.pdf'

set AXES  = '-JX12.0/10.0'
set REGION  = '-R-0.2E-00/14.2E-00/0.0E-00/1.1E-00'
set AXEST  = '-JX12.0/10.0 -R0./12.0/0./10.0'
set XY0 = '-X0. -Y0.'
set XY1 = '-X5.0 -Y3.0'

set TITLESTUFF = '6. 10.5 14 0. 0 BC '
set TITLE = ''

set DATA = 'tcw_VTEM_dec2'
awk 'NF > 1 {print $1,$2}'  ${DATA}  >! temp.xy
psxy  temp.xy  ${AXES}  ${REGION}  -Bf1.a2.:"Time  (ms)":/f0.1a0.5:"Current  (A)":WSne  \
          -Sc0.1 -W3  ${XY1}  -K   >!  ${PSFILE}
psxy  temp.xy  ${AXES}  ${REGION}  -W3  ${XY0}  -O -K   >>  ${PSFILE}

echo ${TITLESTUFF} ${TITLE} | pstext  ${AXEST}  -N ${XY0} -O  >>  ${PSFILE}


ps2pdf ${PSFILE} ${PDFFILE}
echo ${PDFFILE} ' done'

\rm temp.xy

exit

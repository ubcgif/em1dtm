#!/bin/csh
#
# For plotting em1dtm predicted data.
#

gmtset PAPER_MEDIA letter+
gmtset PAGE_ORIENTATION portrait
gmtset ANOT_FONT_SIZE 12
gmtset LABEL_FONT_SIZE 16
gmtset TICK_LENGTH 0.20

head  -29  em1dtmfwd.out_model00  |  tail -25  |  awk '{print $1,$3,$5}' -    >! tV_noisy_00
tail  -25  em1dtmfwd.out_model00  |               awk '{print $1,$3}' -       >! tV_00
head  -29  em1dtmfwd.out_model10  |  tail -25  |  awk '{print $1,$3,$5}' -    >! tV_noisy_10
tail  -25  em1dtmfwd.out_model10  |               awk '{print $1,$3}' -       >! tV_10

set PSFILE = 'tV_00_10.eps'
set PDFFILE = 'tV_00_10.pdf'

set AXES  = '-JX12.0/10.0'
set AXES2  = '-JX12.0/10.0l'
set REGION  = '-R6.0E-00/14.E-00/-0.1E-00/1.5E-00'
set REGION2  = '-R6.0E-00/14.E-00/5.0E-05/2.0E-00'
set AXEST  = '-JX12.0/10.0 -R0./12.0/0./10.0'
set XY0 = '-X0. -Y0.'
set XY1 = '-X5.0 -Y3.0'
set XY2 = '-X0. -Y13.5'

set TITLESTUFF = '6. 10.5 14 0. 0 BC '
set TITLE = ''

set DATA = 'tV_00'
psxy  ${DATA}  ${AXES}  ${REGION}  -Bf1.a2.:"Time  (ms)":/f0.25a0.5:"Voltage  (@~m@~V)":WSne  \
          -W4/0/255/0  ${XY1}  -K   >!  ${PSFILE}
set DATA = 'tV_10'
psxy  ${DATA}  ${AXES}  ${REGION}  -W4/0/0/255  ${XY0}  -O -K   >>  ${PSFILE}
set DATA = 'tV_noisy_00'
psxy  ${DATA}  -JX  -R  -Sc0.1c -Ey0.2/3/0/255/0 ${XY0}  -O -K  >>  ${PSFILE}
set DATA = 'tV_noisy_10'
psxy  ${DATA}  -JX  -R  -Sc0.1c -Ey0.2/3/0/0/255 ${XY0}  -O -K  >>  ${PSFILE}

echo ${TITLESTUFF} ${TITLE} | pstext  ${AXEST}  -N ${XY0} -O -K  >>  ${PSFILE}


set DATA = 'tV_00'
awk '{print $1,sqrt($2*$2)}' ${DATA}  >! temp.xy
psxy  temp.xy  ${AXES2}  ${REGION2}  -Bf1.a2.:"Time  (ms)":/f3a1:"Voltage  (@~m@~V)":WSne  \
          -W4/0/255/0  ${XY2}  -O -K   >>  ${PSFILE}
set DATA = 'tV_10'
awk '{print $1,sqrt($2*$2)}' ${DATA}  >! temp.xy
psxy  temp.xy  ${AXES2}  ${REGION2}  -W4/0/0/255  ${XY0}  -O -K   >>  ${PSFILE}
set DATA = 'tV_noisy_00'
awk '{print $1,sqrt($2*$2),$3}' ${DATA}  >! temp.xy
psxy  temp.xy  -JX  -R  -Sc0.1c -Ey0.2/3/0/255/0  ${XY0}  -O -K  >>  ${PSFILE}
set DATA = 'tV_noisy_10'
awk '{print $1,sqrt($2*$2),$3}' ${DATA}  >! temp.xy
psxy  temp.xy  -JX  -R  -Sc0.1c -Ey0.2/3/0/0/255  ${XY0}  -O -K  >>  ${PSFILE}

echo ${TITLESTUFF} ${TITLE} | pstext  ${AXEST}  -N ${XY0} -O   >>  ${PSFILE}


ps2pdf ${PSFILE} ${PDFFILE}
echo ${PDFFILE} ' done'


exit

#!/bin/csh
# For plotting conductivity model and data for EM1DTM.
#

set MODFILE = test_con.mod
set OBSFILE = ../../VTEM_11locs-2.obs
set PRDFILE = test.prd
set FILE1 = modcon.out
set CPTFILE = lsig.cpt
set PSFILE = p.ps
set PDFFILE = p.pdf
set MIN = -3.5
set MAX = -1.5
set D   = 0.005
set PROJ = '-JX6.5/-3.55'
set REGION = '-R-50./1050./0./600.'
set PROJT = '-JX6.5/3.55'
set REGIONT = '-R0./6.5/0./3.55.'
set PROJ2 = '-JX6.5/4l'
set REGION2 = '-R-50./1050./0.8E-04/0.2E+01'
set TCKINTX = 200
set TCKINTZ = 100
set TCKINTD = f3a1
set XY1 = '-X1.2 -Y2.0'
set XY2 = '-X0.0 -Y4.3'
set CLRBRD = '-D3.25/-1.0/4./0.1h'

gmtset ANOT_FONT_SIZE 12
gmtset LABEL_FONT_SIZE 15
gmtset TICK_LENGTH 0.07

gmtset MEASURE_UNIT inch

gmtset PAPER_MEDIA letter+
# gmtset PAPER_MEDIA letter
gmtset PAGE_ORIENTATION portrait
# gmtset PAGE_ORIENTATION landscape


makecpt -Crainbow -T${MIN}/${MAX}/${D}  >! $CPTFILE

../../modcon  << Endofinput
$MODFILE
$CPTFILE
Endofinput

psxy $FILE1  $PROJ $REGION  -M -L   $XY1  -K  >! $PSFILE

psbasemap  ${PROJ}  ${REGION}  -B${TCKINTX}:"X (m)":/${TCKINTZ}:"Z (m)":WSne \
             -K -O   >>  $PSFILE

psscale -Clsig.cpt $CLRBRD -Bf0.1a0.5:"log@-10@- conductivity  (S/m)": -O -K >> $PSFILE

# pstext  $PROJT $REGIONT -N  -O -K  >> $PSFILE << EOI
# 3.25 3.8 16 0. 8 BC ${MODFILE}
# EOI


../../prdcon  << Endofinput
$PRDFILE
Endofinput

psxy  prdcon01.out  $PROJ2 $REGION2  -B${TCKINTX}/${TCKINTD}:"Voltage (@~m@~V)":WSne  \
             -W2/0/0/255  $XY2  -K -O  >>  $PSFILE
psxy  prdcon02.out  $PROJ2 $REGION2  -W2/0/0/255  -K -O  >>  $PSFILE
psxy  prdcon03.out  $PROJ2 $REGION2  -W2/0/0/255  -K -O  >>  $PSFILE
psxy  prdcon04.out  $PROJ2 $REGION2  -W2/0/0/255  -K -O  >>  $PSFILE
psxy  prdcon05.out  $PROJ2 $REGION2  -W2/0/0/255  -K -O  >>  $PSFILE
psxy  prdcon06.out  $PROJ2 $REGION2  -W2/0/0/255  -K -O  >>  $PSFILE
psxy  prdcon07.out  $PROJ2 $REGION2  -W2/0/0/255  -K -O  >>  $PSFILE
psxy  prdcon08.out  $PROJ2 $REGION2  -W2/0/0/255  -K -O  >>  $PSFILE
psxy  prdcon09.out  $PROJ2 $REGION2  -W2/0/0/255  -K -O  >>  $PSFILE
psxy  prdcon10.out  $PROJ2 $REGION2  -W2/0/0/255  -K -O  >>  $PSFILE
psxy  prdcon11.out  $PROJ2 $REGION2  -W2/0/0/255  -K -O  >>  $PSFILE
psxy  prdcon12.out  $PROJ2 $REGION2  -W2/0/0/255  -K -O  >>  $PSFILE
psxy  prdcon13.out  $PROJ2 $REGION2  -W2/0/0/255  -K -O  >>  $PSFILE
psxy  prdcon14.out  $PROJ2 $REGION2  -W2/0/0/255  -K -O  >>  $PSFILE
psxy  prdcon15.out  $PROJ2 $REGION2  -W2/0/0/255  -K -O  >>  $PSFILE
psxy  prdcon16.out  $PROJ2 $REGION2  -W2/0/0/255  -K -O  >>  $PSFILE
psxy  prdcon17.out  $PROJ2 $REGION2  -W2/0/0/255  -K -O  >>  $PSFILE
psxy  prdcon18.out  $PROJ2 $REGION2  -W2/0/0/255  -K -O  >>  $PSFILE
psxy  prdcon19.out  $PROJ2 $REGION2  -W2/0/0/255  -K -O  >>  $PSFILE
psxy  prdcon20.out  $PROJ2 $REGION2  -W2/0/0/255  -K -O  >>  $PSFILE
psxy  prdcon21.out  $PROJ2 $REGION2  -W2/0/0/255  -K -O  >>  $PSFILE
psxy  prdcon22.out  $PROJ2 $REGION2  -W2/0/0/255  -K -O  >>  $PSFILE
psxy  prdcon23.out  $PROJ2 $REGION2  -W2/0/0/255  -K -O  >>  $PSFILE
psxy  prdcon24.out  $PROJ2 $REGION2  -W2/0/0/255  -K -O  >>  $PSFILE
psxy  prdcon25.out  $PROJ2 $REGION2  -W2/0/0/255  -K -O  >>  $PSFILE



../../obscon  << Endofinput
$OBSFILE
Endofinput

psxy  obscon01.out  $PROJ2 $REGION2  -Sc0.02  -Ey0.04  -K -O  >>  $PSFILE
psxy  obscon02.out  $PROJ2 $REGION2  -Sc0.02  -Ey0.04  -K -O  >>  $PSFILE
psxy  obscon03.out  $PROJ2 $REGION2  -Sc0.02  -Ey0.04  -K -O  >>  $PSFILE
psxy  obscon04.out  $PROJ2 $REGION2  -Sc0.02  -Ey0.04  -K -O  >>  $PSFILE
psxy  obscon05.out  $PROJ2 $REGION2  -Sc0.02  -Ey0.04  -K -O  >>  $PSFILE
psxy  obscon06.out  $PROJ2 $REGION2  -Sc0.02  -Ey0.04  -K -O  >>  $PSFILE
psxy  obscon07.out  $PROJ2 $REGION2  -Sc0.02  -Ey0.04  -K -O  >>  $PSFILE
psxy  obscon08.out  $PROJ2 $REGION2  -Sc0.02  -Ey0.04  -K -O  >>  $PSFILE
psxy  obscon09.out  $PROJ2 $REGION2  -Sc0.02  -Ey0.04  -K -O  >>  $PSFILE
psxy  obscon10.out  $PROJ2 $REGION2  -Sc0.02  -Ey0.04  -K -O  >>  $PSFILE
psxy  obscon11.out  $PROJ2 $REGION2  -Sc0.02  -Ey0.04  -K -O  >>  $PSFILE
psxy  obscon12.out  $PROJ2 $REGION2  -Sc0.02  -Ey0.04  -K -O  >>  $PSFILE
psxy  obscon13.out  $PROJ2 $REGION2  -Sc0.02  -Ey0.04  -K -O  >>  $PSFILE
psxy  obscon14.out  $PROJ2 $REGION2  -Sc0.02  -Ey0.04  -K -O  >>  $PSFILE
psxy  obscon15.out  $PROJ2 $REGION2  -Sc0.02  -Ey0.04  -K -O  >>  $PSFILE
psxy  obscon16.out  $PROJ2 $REGION2  -Sc0.02  -Ey0.04  -K -O  >>  $PSFILE
psxy  obscon17.out  $PROJ2 $REGION2  -Sc0.02  -Ey0.04  -K -O  >>  $PSFILE
psxy  obscon18.out  $PROJ2 $REGION2  -Sc0.02  -Ey0.04  -K -O  >>  $PSFILE
psxy  obscon19.out  $PROJ2 $REGION2  -Sc0.02  -Ey0.04  -K -O  >>  $PSFILE
psxy  obscon20.out  $PROJ2 $REGION2  -Sc0.02  -Ey0.04  -K -O  >>  $PSFILE
psxy  obscon21.out  $PROJ2 $REGION2  -Sc0.02  -Ey0.04  -K -O  >>  $PSFILE
psxy  obscon22.out  $PROJ2 $REGION2  -Sc0.02  -Ey0.04  -K -O  >>  $PSFILE
psxy  obscon23.out  $PROJ2 $REGION2  -Sc0.02  -Ey0.04  -K -O  >>  $PSFILE
psxy  obscon24.out  $PROJ2 $REGION2  -Sc0.02  -Ey0.04  -K -O  >>  $PSFILE
psxy  obscon25.out  $PROJ2 $REGION2  -Sc0.02  -Ey0.04   -O  >>  $PSFILE


ps2pdf  $PSFILE  $PDFFILE

echo  $PDFFILE ' done.'

\rm $CPTFILE $FILE1 prdcon??.out obscon??.out

exit

#!/bin/csh
#
# For plotting em1dtm predicted data.
#

gmtset PAPER_MEDIA letter+
gmtset PAGE_ORIENTATION portrait
gmtset ANOT_FONT_SIZE 12
gmtset LABEL_FONT_SIZE 16
gmtset TICK_LENGTH 0.25

head -24  em1dtmfwd.out  |  tail -20  |  awk '{print $1,$3,$5}' -  >!  data1
tail -20  em1dtmfwd.out  |               awk '{print $1,$3}' -     >!  data2
tail -20  ../tV_step/em1dtmfwd.out  |    awk '{print $1,$3}' -     >!  data3

set PSFILE = 'ttVeps'
set PDFFILE = 'tV.pdf'

set AXES  = '-JX12.0l/10.0l'
set REGION  = '-R0.55E-05/9.0E-04/2.0E-02/3.0E+02'
set AXEST  = '-JX12.0/10.0 -R0./12.0/0./10.0'
set XY0 = '-X0. -Y0.'
set XY1 = '-X5.0 -Y3.0'

set TITLESTUFF = '6. 10.6 14 0. 0 BC '
set TITLE = 'EM1DTMFWD'

awk '{print $1,sqrt($2*$2),$3}' data1  >! temp.xy
psxy  temp.xy  ${AXES}  ${REGION}  -Bf3a1:"Time  (s)":/f3a1:"Voltage  (@~m@~V)":WSne  \
          -Sc0.01c -Ey0.15/3/0/0/0 -W3  ${XY1}  -K   >!  ${PSFILE}

awk '{print $1,sqrt($2*$2)}' data2  >! temp.xy
psxy  temp.xy  -JX  -R  -W3/0/0/0  ${XY0}  -O -K  >>  ${PSFILE}

awk '{print $1,sqrt($2*$2)}' data3  >! temp.xy
psxy  temp.xy  -JX  -R  -W2/0/0/0  ${XY0}  -O -K  >>  ${PSFILE}

echo ${TITLESTUFF} ${TITLE} | pstext  ${AXEST}  -N ${XY0} -O  >>  ${PSFILE}


ps2pdf ${PSFILE} ${PDFFILE}
echo ${PDFFILE} ' done'

\rm data1 data2 temp.xy

exit

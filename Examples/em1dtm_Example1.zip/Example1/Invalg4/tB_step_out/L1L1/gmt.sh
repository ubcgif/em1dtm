#!/bin/csh
#
# For plotting em1dtm predicted data.
#

gmtset PAPER_MEDIA letter+
gmtset PAGE_ORIENTATION portrait
gmtset ANOT_FONT_SIZE 12
gmtset LABEL_FONT_SIZE 16
gmtset TICK_LENGTH 0.25

head -26  ../tB_step_out.obs  |  tail -20  |  awk '{print $1,$3,$5}' -  >!  data1
tail -20  test.prd     |               awk '{print $1,$3}' -     >!  data2

../../../thtodpth << EOI
test.con
model
EOI

cat >> truemodel << EOI
  0.  0.01
 25.  0.01
 25.  0.1
 50.  0.1
 50.  0.05
100.  0.05
200.  0.05
300.  0.05
EOI

awk 'NR > 9 && NF > 7  {print $1,$3}'  test_001.dgns  >!  iterphid
awk 'NR > 9 && NF > 7  {print $1,$4}'  test_001.dgns  >!  iterbeta
awk 'NR > 9 && NF > 7  {print $1,$5}'  test_001.dgns  >!  iterphim
awk 'NR > 10 && NF > 7  {print $1,$6}'  test_001.dgns  >!  iterPhi

set PSFILE1 = 'md.eps'
set PDFFILE1 = 'md.pdf'
set PSFILE2 = 'ip.eps'
set PDFFILE2 = 'ip.pdf'

set AXESD  = '-JX12.0l/10.0l'
set REGIOND  = '-R0.55E-05/9.0E-04/1.0E-02/3.0E-00'
set AXEST  = '-JX12.0/10.0 -R0./12.0/0./10.0'
set AXESM  = '-JX12.0/8.0l'
set REGIONM  = '-R0.0/1.7E+02/0.2E-02/2.0E-01'
set AXES1  = '-JX14.0/14.0l'
set REGION1  = '-R-1.0/30.0/0.1E-01/1.0E+05'
set XY0 = '-X0. -Y0.'
set XY1 = '-X5.0 -Y15.0'
set XY2 = '-X0.0 -Y-11.0'
set XY3 = '-X4.0 -Y5.0'

set TITLESTUFF = '6. 11.0 14 0. 0 BC '
set TITLE = 'EM1DTM'

awk '{print $1,sqrt($2*$2),$3}' data1  >! temp.xy
psxy  temp.xy  ${AXESD}  ${REGIOND}  -Bf3a1:"Time  (s)":/f3a1:"B@-z@-  (nT)":WSne  \
          -Sc0.01c -Ey0.15/3/0/0/0 -W3  ${XY1}  -K   >!  ${PSFILE1}

awk '{print $1,sqrt($2*$2)}' data2  >! temp.xy
psxy  temp.xy  -JX  -R  -W3/0/0/0  ${XY0}  -O -K  >>  ${PSFILE1}

echo ${TITLESTUFF} ${TITLE} | pstext  ${AXEST}  -N ${XY0} -O -K  >>  ${PSFILE1}

psxy  model  ${AXESM}  ${REGIONM}  -Bf10a50:"Depth  (m)":/f3a1:"Conductivity  (S/m)":WSne  \
          -W4/0/0/0  ${XY2}  -O -K   >>  ${PSFILE1}

psxy  truemodel  -JX  -R  -W2  ${XY0}  -O  >>  ${PSFILE1}


ps2pdf ${PSFILE1} ${PDFFILE1}
echo ${PDFFILE1} ' done'


psxy  iterphid  ${AXES1}  ${REGION1}  -Bf1a5:"Iteration":/f3a1:"Phis":WSne  \
          -Sc0.2c -W3  ${XY3}  -K   >!  ${PSFILE2}
psxy  iterphid  -JX  -R  -W2/0/0/0  ${XY0}  -O -K  >>  ${PSFILE2}
psxy  iterbeta  -JX  -R  -Sx0.2c -W3  ${XY0}  -O -K  >>  ${PSFILE2}
psxy  iterbeta  -JX  -R  -W2/0/0/0  ${XY0}  -O -K  >>  ${PSFILE2}
psxy  iterphim  -JX  -R  -Sd0.2c -W3  ${XY0}  -O -K  >>  ${PSFILE2}
psxy  iterphim  -JX  -R  -W2/0/0/0  ${XY0}  -O -K  >>  ${PSFILE2}
psxy  iterPhi   -JX  -R  -Sc0.2c -W3 -G0  ${XY0}  -O -K  >>  ${PSFILE2}
psxy  iterPhi   -JX  -R  -W2/0/0/0  ${XY0}  -O  >>  ${PSFILE2}


ps2pdf ${PSFILE2} ${PDFFILE2}
echo ${PDFFILE2} ' done'

\rm data1 data2 temp.xy model truemodel iterphid iterbeta iterphim iterPhi

exit
